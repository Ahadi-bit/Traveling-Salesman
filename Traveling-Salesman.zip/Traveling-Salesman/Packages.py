from hashing import HashTable
import csv


# Reads Packages.csv file for package info and inserts them within the hash table - O(n)
def get_packages():
    with open('data/Packages.csv') as csv_package_file:
        readCSV = csv.reader(csv_package_file, delimiter=',')
        lines = list(readCSV)
        packageTable = HashTable(len(lines))  # Initialize the hash table object with the amount of packages in the csv file
        for row in lines:
            package_id = row[0]
            package_address = row[1]
            package_city = row[2]
            package_state = row[3]
            package_zip = row[4]
            package_deadline = row[5]
            package_mass = row[6]
            package_notes = row[7]
            package_status = 'At the hub'

            package = [package_id, package_address, package_city, package_state, package_zip,
                       package_deadline, package_mass, package_notes, package_status]

            packageTable.insert(package)

        return packageTable


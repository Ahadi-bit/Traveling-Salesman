## Jonathan Payares
from Packages import get_packages
from menu import startMenu
import csv
from datetime import *
from termcolor import cprint
from prettytable import PrettyTable

# pretty Table - Used for creating the tables of data in the command line
table = PrettyTable()
table.field_names = ['Package ID', 'Address', 'City ', 'State', 'Zip', 'Delivery Deadline', 'Mass KILO', 'Notes',
                     'Status']

# gets packages and stores to a variable
chaining = get_packages()

# stores distances into list
distances_list = []
with open('data/Distances.csv') as csv_distances:
    readCSV = csv.reader(csv_distances, delimiter=',')
    for row in readCSV:
        distances_list.append(row)
        # print(row)

    csv_distances.close()

# dictionary for address for deliveries
dictionary = {}

# adds the address for each location in a the dictionary
i = 0
for distance in distances_list:
    dictionary[distance[0]] = i
    i += 1

truck1 = [1, 25, 13, 14, 15, 16, 19, 20, 29, 30, 31, 34, 37, 39, 40]  # package IDs for truck 1
truck2 = [3, 6, 7, 18, 21, 28, 32, 36, 38]  # package IDs for truck 2
truck3 = [2, 4, 5, 8, 9, 10, 11, 12, 17, 22, 23, 24, 26, 27, 33, 35]  # package IDs for truck 3
deliveries = [truck1, truck2, truck3]  # order of each truck

start_time = datetime(2021, 3, 20, 8, 0)
truck_time = datetime(2021, 3, 20, 8, 0)

total_distance = 0.0  # Used to track total distance of packages
truck_counter = 0  # User to track which truck is being used

# runs through the trucks one at a time(only 1 truck and driver out at a time)
# Instead of looping this functionality I could add a manual step during simulation
# to shrink complexity
# O(n^3)
for delivery in deliveries:
    # current truck out
    truck = []
    # current location starting at 4001 South 700 East
    curr_location = distances_list[1][0]

    # add truck to counter
    truck_counter += 1
    print("Truck", truck_counter, "is being loaded")

    cprint("-----------------------------", "cyan")
    # loads packages into truck - O(n)
    for item in delivery:
        truck.append(chaining.table[item][0])
        truck_time += timedelta(seconds=30)
        cprint("| Loading Truck: Package # " + str(chaining.table[item][0][0]) + " |", "cyan")
    cprint("-----------------------------", "cyan")
    print("")

    # sets status to En Route - O(n)FF
    for package in truck:
        chaining.insert(package, "En Route")

    cprint("Starting Time: " + str(truck_time), "blue")
    cprint("Starting Location: " + curr_location, "blue")
    print("")

    # loops through the amount of packages in the truck O(n^2)
    while len(truck) != 0:

        destination = distances_list[dictionary[truck[0][1]]][0]  # destination of next package
        next_package = truck[0][0]  # The next package
        next_package_range = 99.0  # distance to next package. high number to make sure package is length is lower

        # loops through the packages in the truck - O(n)
        for package in truck:

            # used to compare locations
            temp_next_location = package[1]
            # Finds the distance to the next place. If table is blank, swaps them and looks again.
            if distances_list[dictionary[temp_next_location]][dictionary[curr_location]] == "":

                temp_distance = float(distances_list[dictionary[curr_location]][dictionary[temp_next_location]])
            else:
                temp_distance = float(distances_list[dictionary[temp_next_location]][dictionary[curr_location]])

            # Compare locations to see which location is the closest.
            if temp_distance < next_package_range:
                next_package_range = temp_distance
                destination = temp_next_location
                next_package = chaining.table[int(package[0])][0]

        print("")
        cprint("Next Package: " + str(next_package[0]), "magenta")
        cprint("Next Package Address: " + str(next_package[1]), "magenta")
        cprint("Distance to next location: " + str(next_package_range), "yellow")

        deliver_duration = next_package_range * (60 / 18)  # duration the package based on trucks only about to go 18MPH
        truck_time += timedelta(minutes=(int(deliver_duration)))  # adds to delivery duration to trucks time
        total_distance += next_package_range  # adds package distance to the total distance
        curr_location = distances_list[dictionary[destination]][0]  # updates current location

        cprint("Delivered at " + str(truck_time), "green")  # Informs user package was delivered
        chaining.insert(next_package, "Delivered at " + str(truck_time))  # Updates table and passed status of package

        table.add_row(next_package)  # adds package to final status table

        truck.remove(next_package)  # removes package from truck
        # When all the truck is empty it will run the truck back to HUB
        if len(truck) == 0:
            destination = distances_list[1][0]  # sets destination back to hub
            next_package_range = float(distances_list[dictionary[curr_location]][1])  # range from location to hub
            total_distance += next_package_range  # adds time to total distance
            curr_location = distances_list[dictionary[destination]][0]

            # Display user
            print("-----------------------------------------------------------------------------")
            cprint("All packages on Truck have been delivered.", "green")
            cprint("Returning to hub. The distance to the hub is " + str(next_package_range) + " miles.", "green")
            cprint("Truck has returned to the hub having travelled a total of " + str(total_distance) + " miles.",
                   "green")
            cprint("The truck left the hub at " + str(start_time) + ".", "green")
            cprint("The truck returned at " + str(truck_time) + ".", "green")
            print("-----------------------------------------------------------------------------")
            start_time = truck_time

# gives final status of the package
print("Final Status:")
cprint(table.get_string(fields=["Package ID", "Address", "Delivery Deadline", "Status", "Notes"]), "blue")
print("")
startMenu(chaining)

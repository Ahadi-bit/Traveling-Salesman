# Chaining hash table
class HashTable:

    # Initializes the hash table with empty buckets
    # takes in the the size of the data and creates the buckets
    # O(n)
    def __init__(self, size=41):
        self.table = []
        for i in range(size):
            self.table.append([])

    # Basic hash function that uses that uses the package as a key - O(1)
    def __getHash(self, key):
        return key % len(self.table)

    # Inserts a new item into the hash table
    # also used for updating of already existing packages - O(1)
    def insert(self, key, status= ""):
        if key[0] != "Package ID":
            key_id = int(key[0])
            bucket = self.__getHash(key_id)
            bucket_list = self.table[bucket]

            # If the key exist in the bucket_list, it will update its status
            if key in bucket_list:
                bucket_list[0][8] = status
            else:
                bucket_list.append(key)

    # Search function finds users looks and returns the item if it exists in the list - O(1)
    def search(self, key):
        bucket = self.__getHash(int(key[0]))
        bucket_list = self.table[bucket]

        # If the key exist in the bucket_list, it will return the item
        if key in bucket_list:
            item_index = bucket_list.index(key)
            return bucket_list[item_index]
        else:
            return None

    # Removes an item from the the hash table if it exists - O(1)
    def remove(self, key):
        bucket = self.__getHash(int(key[0]))
        bucket_list = self.table[bucket]

        # If the key exist in the bucket_list, it will remove the item
        if key in bucket_list:
            bucket_list.remove(key)

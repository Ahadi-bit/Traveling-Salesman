#Traveling Salesman Problem


### self-adjusting algorithm (e.g., “Nearest Neighbor algorithm,” “Greedy algorithm”) that you used to create your program to deliver the packages.
    I used the nearest neighbor algorithm to compare the closest location. After Looping through the packages 
    designated for a specific truck (which is statically defined), I would compare the distances of all the
    packages on the truck with the current location of the package. Once the nearest neighbor is decided 
    it would deliver the package. This statement is looped through until all packages on the truck are delivered

### B.  Write an overview of your program, in which you do the following:
#### 1. Explain the algorithm's logic using pseudocode.
    deliveries := list of designated packages to be loaded for each truck
    for each delivery in deliveries list
        for each package assigned to that truck
            load package to truck
        
        While the truck still has items
            Assign first package as temporary location
            for each package on truck
                compares the distances of each package and find the closest package to the current location

#### 2. Describe the programming environment you used to create the Python application.
    Software:
        - IDE: PyCharm 2020.3.3
        - Python 3.9
        - Windows 10
        - libraries used:
            - Pretty Table for table creation
            - term color for color in command line GUI
    Hardware:
        - AMD Ryzen 5 2600 six-core processor 3.4 GHz
        - 32 GB ram
 
#
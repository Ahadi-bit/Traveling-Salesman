from termcolor import cprint
from prettytable import PrettyTable
from datetime import *

# PrettyTable library for building the header for the table
timeFrameTable = PrettyTable()
time_frame = []
timeFrameTable.field_names = ['Package ID', 'Address', 'City ', 'State',
                              'Zip', 'Delivery Deadline', 'Mass KILO', 'Notes', 'Status']


# Main menu for command line GUI.
# Functionality for pulling data during a specific time frame
# Functionality for looking up a specific package based on package ID
# O(n log n)
def startMenu(chaining):
    lookup_status = True
    # Controls the menu based on what the user chooses - O(log n)
    while lookup_status is True:
        lookup = input("- Would you like Look up a package? Type 1!"
                       "\n- Would you like to check packages during a specific time frame? Type 2!"
                       "\n- you can cancel by typing 3"
                       "\n- Please type here:")
        # Option 1 is searching for the package ID if the user find the package Item is displayed
        # if the user types and item incorrectly(such as a string) or looks for a packagge that cant be found it will
        # catch the error and display: No Item Found! Try Again.
        if lookup == "1":
            # Ask for package ID
            item_to_search = input("Type the Package ID you are searching for")
            try:
                # Search for item in hash table
                item_found = chaining.search(chaining.table[int(item_to_search)][0])
                cprint("Item Found!" + str(item_found), "green")

                # ask user if they wish to terminate.
                confirm = str.upper(input("Would you like to look again? Enter \'Y\' or \'N\'"))
                if confirm == "Y":
                    continue
                elif confirm == "N":
                    lookup_status = False
                else:
                    print("Invalid Input")
                    lookup_status = False
            except:
                cprint("-------------------------", "red")
                cprint('No Item Found! Try Again.', 'red')
                cprint("-------------------------", "red")

        # Option 2 find packages delivered between a certain time frame. by entering the hours and minutes to search
        elif lookup == "2":
            # request user to enter starting time (hour and minutes)
            starting_hrs = input("Please input the starting times hour between 0-23.(ex 9:25? enter 9) ")
            starting_mins = input("Please input the starting times minutes between 0-59.(ex 9:25? enter 25) ")
            # request user to enter end time (hour and minutes)
            ending_hrs = input("Please input the end times hour between 0-23.(ex 9:25? enter 9) ")
            ending_mins = input("Please input the end times minutes between 0-59.(ex 9:25? enter 25) ")

            # build time in proper datetime format
            starting_time = datetime(2021, 3, 20, int(starting_hrs), int(starting_mins), 0)
            ending_time = datetime(2021, 3, 20, int(ending_hrs), int(ending_mins), 0)

            # check that time is correctly entered
            try:
                # makes sure the ending time and starting time are correctly entered
                if ending_time >= starting_time:
                    # loops through the packages O(n)
                    for packages in chaining.table:

                        if not packages:
                            continue
                        else:
                            # slices the datetime from the package
                            sliced_time = datetime.strptime(packages[0][8][13:], "%Y-%m-%d %H:%M:%S")
                            # comparison for the starting time
                            if starting_time <= sliced_time <= ending_time:
                                time_frame.append(packages[0])
                                timeFrameTable.add_row(packages[0])

                            else:
                                continue

                    # builds tabulated data
                    print(timeFrameTable.get_string(
                        fields=["Package ID", "Address", "Delivery Deadline", "Status", "Notes"]))
                    print()

                    # ask user if they wish to terminate.
                    confirm = str.upper(input("Would you like to look again? Enter \'Y\' or \'N\'"))
                    if confirm == "Y":
                        continue
                    elif confirm == "N":
                        lookup_status = False
                    else:
                        print("Invalid Input")
                        lookup_status = False

                else:
                    cprint("-----------------------------------------------", "red")
                    cprint("ending time must be greater than starting time!", "red")
                    cprint("-----------------------------------------------", "red")

            except:
                cprint("------------------------------------------------------------------------", "red")
                cprint("Invalid input!\nhours must be between 0-23\nminutes must be between 0-59", "red")
                cprint("------------------------------------------------------------------------", "red")
        # Option 3 closes application
        elif lookup == "3":
            lookup_status = False
        else:
            lookup_status = False
